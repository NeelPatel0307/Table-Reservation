const axios = require('axios');
const admin = require('firebase-admin');
const functions = require('firebase-functions');

admin.initializeApp();

const firestore = admin.firestore();

exports.getAllReservations = functions.https.onRequest(async (req, res) => {
  try {
    // Fetch data from DynamoDB API
    const dynamoDBResponse = await axios.get(
      'https://northamerica-northeast1-serverless-402317.cloudfunctions.net/get-reservation'
    );

    const reservationData = dynamoDBResponse.data.data;

    // Store data in Firestore
    const batch = firestore.batch();

    reservationData.forEach((reservation) => {
      const reservationRef = firestore.collection('reservations').doc(reservation.reservation_id);
      batch.set(reservationRef, reservation);
    });

    await batch.commit();

    return res.status(200).json({ success: true, message: 'Data synced successfully' });
  } catch (error) {
    console.error('Error syncing data:', error);
    return res.status(500).json({ success: false, error: 'Internal Server Error' });
  }
});